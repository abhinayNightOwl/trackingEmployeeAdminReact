import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { GoogleMap, LoadScript } from '@react-google-maps/api';
import { useParams } from 'react-router-dom';
const EmployeeLocation = () => {
  const { latitude, longitude } = useParams();

  const mapStyles = {
    height: "100vh",
    width: "100%"
  };

  const defaultCenter = {
    lat: 41.3851,
    lng: 2.1734
  };

  return (
    <div style={{ height: '100px', width: '100%' }}>
      <MapContainer center={[latitude, longitude]} zoom={15} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; <Link to="https://www.openstreetmap.org/copyright">OpenStreetMap</Link> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Marker position={[latitude, longitude]}>
          <Popup>
            Employee Location
          </Popup>
        </Marker>
      </MapContainer>
       {/* <LoadScript googleMapsApiKey="AIzaSyCaq-CdfPrOejI2218uvN0xzKt6LjnuTBc">
       <GoogleMap
        mapContainerStyle={mapStyles}
        zoom={13}
        center={defaultCenter}
      />
    </LoadScript>*/}
     </div>  
  );
};
export default EmployeeLocation;