(function($) {
	"use strict";
	//P-scrolling
	const ps = new PerfectScrollbar('.sidebar-left', {
	  useBothWheelAxes:false,
	  suppressScrollX:false,
	});
	
})(jQuery);